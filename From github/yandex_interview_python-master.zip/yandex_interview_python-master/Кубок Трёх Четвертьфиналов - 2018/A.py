import sys
n = [int(x) for x in sys.stdin.readline().strip().split(' ')]
print(n[0] + n[1])
